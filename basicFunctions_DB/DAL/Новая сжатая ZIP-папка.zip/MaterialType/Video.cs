﻿namespace basicFunctions_DB.DAL.MaterialType
{
    public class Video : Material
    {
        public int Resolution { get; set; }

        public int Duration { get; set; }
    }
}
